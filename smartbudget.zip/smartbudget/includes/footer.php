<?php if(isset($_SESSION["user_id"])): ?>
    </main>
</div>
<?php endif; ?>

<script src="/smartbudget/assets/js/luxury.js?v=4"></script>
</body>
</html>
