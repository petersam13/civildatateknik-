# SimTradeBot
C++ Backtesting & Strategy Evaluation Framework

## Projektöversikt
SimTradeBot är ett C++-baserat ramverk för simulering och utvärdering av algoritmiska handelsstrategier (backtesting).  
Projektet är utvecklat som ett kursprojekt för att demonstrera objektorienterad programmering, arkitektur, externbibliotek, datastrukturer och dokumentation.

Applikationen läser historisk prisdata från CSV-filer, applicerar handelsstrategier, simulerar exekvering och riskhantering samt visualiserar resultatet i statistik och interaktiva HTML-grafer.

---

## Syfte
Syftet med projektet är att:
- simulera algoritmisk handel på historisk marknadsdata  
- utvärdera strategiers lönsamhet och risk  
- demonstrera objektorienterad design i C++  
- visa hur externa bibliotek och designmönster används i praktiken  

---

## Funktionalitet

### Marknadsdata
- CSV-baserad marknadsdatafeed (`CsvMarketDataFeed`)
- Observer-mönster för distribution av ticks

### Strategier
- Abstrakt basklass `TradingStrategy`
- Implementerad Mean Reversion-strategi
- Lätt att utöka med fler strategier

### Backtest & Risk
- BacktestEngine som:
  - tar emot signaler
  - simulerar orderexekvering
  - beräknar equity-kurva
- RiskManager med:
  - max antal trades
  - max position
  - drawdown-stop
- Adaptiv position sizing baserat på volatilitet

### Analys & Statistik
- PerformanceAnalyzer beräknar:
  - Net Profit
  - Max Drawdown
  - Win Rate
  - Profit Factor
  - Sharpe-kvot
- Walk-Forward-analys (train/test-split)

### Visualisering
- HTML-baserad interaktiv graf:
  - pris
  - equity-kurva
  - BUY/SELL-markörer
  - closed trades
  - PnL-histogram per trade

---

## Teknisk arkitektur

include/
└─ simtrade/
├─ core/ (Types, Logger)
├─ data/ (MarketDataFeed, CsvMarketDataFeed)
├─ trading/ (Strategy, Backtest, Risk, Optimizer, WalkForward)
└─ ui/ (HtmlChartWriter)

src/
└─ implementations (*.cpp)


Arkitekturen använder:
- Strategy pattern  
- Observer pattern  
- Separation of concerns  
- RAII och `std::unique_ptr`

---

## Externt bibliotek
Projektet använder det externa C++-biblioteket **fmt**:
- används för formatering och loggning
- integrerat som header-only bibliotek

Exempel:
```cpp
fmt::format("NetProfit: {}", metrics.netProfit);

Bygga och köra
Krav

C++20-kompatibel kompilator

Make

Bygg
make

Kör
make run


Programmet genererar:

terminaloutput med statistik

out_chart.html med interaktiv visualisering

Dokumentation

Koden är dokumenterad med Doxygen-kommentarer i header-filerna.
HTML-dokumentation kan genereras med:

doxygen Doxyfile

Koppling till kursens lärandemål

Projektet demonstrerar:

Objektorienterad programmering i C++

Arv, polymorfism och inkapsling

Användning av externt bibliotek

Modulär och skalbar arkitektur

Dokumentation enligt etablerad standard

Praktisk problemlösning i ett större kodprojekt

Vidare utveckling

Fler strategier (momentum, breakout)

Databasstöd (SQLite)

GUI via SFML eller Qt

Mer avancerad riskmodellering

Författare

Peter Samy
Kursprojekt – C++


